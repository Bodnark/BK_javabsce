package hu.training360.javase.Exceptionclass.packedbk;

import java.math.BigDecimal;

public class Product {
    String name;
    BigDecimal unitWeight;
    int numberOfDecimals;


    public Product(String name, BigDecimal unitWeight, int numberOfDecimals)
    {

    }
    public Product(String name, BigDecimal unitWeight)
    {

    }
    public BigDecimal totalWeight(int pieces)
    {


        return null;
    }

}
