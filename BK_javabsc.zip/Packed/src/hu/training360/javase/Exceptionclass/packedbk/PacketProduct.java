package hu.training360.javase.Exceptionclass.packedbk;

import java.math.BigDecimal;


public class PacketProduct {
    int packingUnit;
    BigDecimal weightOfBox;



    public PacketProduct(String name, BigDecimal unitWeight, int numberOfDecimals, int packingUnit, BigDecimal weightOfBox)
    {
     return;
    }




    public void totalWeight(int prices)
    {
        BigDecimal uj = new BigDecimal("0.145");
        Product p = new Product("LL", uj, 4);
        BigDecimal sum = new BigDecimal("0.475");

    }

}
