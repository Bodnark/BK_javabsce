package hu.training360.javase.Exceptionclass.pendrivebk;

public class Main {

    public static void main(String[] args) {
	// write your code her
        Pendrive p = new Pendrive("xx",1000,1000);
        Pendrive p2 = new Pendrive("yy",2000,2000);
        Pendrive p3 = new Pendrive("zz",3000,3000);


    }


}
