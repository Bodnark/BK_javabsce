package hu.training360.javase.Exceptionclass.pendrivebk;

import java.util.List;

public class Pendrive {
    private String name;
    private int capacity;
    private int price;

    public Pendrive(String name, int capacity, int price) {
        this.name = name;
        this.capacity = capacity;
        this.price = price;
    }



    public String getName() {
        return name;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return "Pendrive{" +
                "name='" + name + '\'' +
                ", capacity=" + capacity +
                ", price=" + price +
                '}';
    }

    public void risePrice( int percent) {
       this.price += (this.price*percent)/100;
    }

    public int comparePricePerCapacityapacity(Pendrive other) {

        double pricep = pricePerCapacity();
        double otherPricep = other.pricePerCapacity();
        if (pricep > otherPricep) {
            return 1;
        }
        if (pricep < otherPricep) {
            return -1;
        }
        return  0;
    }

    public boolean cheaperThan(Pendrive other) {
        return this.price< other.price;

    }


    private double pricePerCapacity() {
        return (double)price/capacity;
    }

    public Pendrive best(List<Pendrive> pendrives) {
        Pendrive min = pendrives.get(0);
        for (int j = 0; j < pendrives.size(); j++) {
            if (min.comparePricePerCapacityapacity(pendrives.get(j)) == 1) {
                min = pendrives.get(j);
            }
        }
        return min;
    }
    public Pendrive cheapest(List<Pendrive> pendrives) {
        Pendrive min = pendrives.get(0);
        for (int j = 0; j < pendrives.size(); j++) {
            if (pendrives.get(j).cheaperThan(min)) {
                min = pendrives.get(j);
            }
        }
        return min;

    }
    public void risePriceWhereCapacity(List<Pendrive> pendrives, int percent, int capacity) {
        for (Pendrive p : pendrives) {
            if (p.getCapacity() == capacity) {
                p.risePrice(percent);
            }
        }
    }
}
